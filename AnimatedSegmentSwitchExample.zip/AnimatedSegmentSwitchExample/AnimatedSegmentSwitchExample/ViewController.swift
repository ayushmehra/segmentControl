//
//  ViewController.swift
//  AnimatedSegmentSwitch
//
//  Created by Tobias Schmid on 09/18/2015.
//  Copyright (c) 2015 Tobias Schmid. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var segmentControl: AnimatedSegmentSwitch!



    
    override func viewDidLoad() {
        super.viewDidLoad()

        UIApplication.shared.statusBarStyle = .lightContent

        navigationController!.navigationBar.isTranslucent = false
     

        
        if let control = segmentControl {
            control.font = UIFont(name: "HelveticaNeue-Medium", size: 17.0)
            control.thumbCornerRadius = 5.0
            control.thumbInset = 0.0

            control.thumbColor = .customGreenColor()
            control.titleColor = .customRedColor()
            control.selectedTitleColor = .white

            control.items = ["Good", "Bad", "Bad", "Bad", "Bad", "Bad"]
        }
    }

   

    @IBAction func segmentValueChanged(_ sender: AnimatedSegmentSwitch!) {

        sender.selectedTitleColor = .white
        print(sender.selectedIndex)
        if sender.selectedIndex == 0 {
            sender.thumbColor = .customGreenColor()
            sender.titleColor = .customRedColor()
        } else if sender.selectedIndex == 1 {
            sender.thumbColor = .customRedColor()
            sender.titleColor = .customGreenColor()
        }
    }
}

extension UIColor {

   

    @objc class func customRedColor() -> UIColor {
        return UIColor(red: 239.0/255.0, green: 95.0/255.0, blue: 49.0/255.0, alpha: 1.0)
    }

    @objc class func customGreenColor() -> UIColor {
        return UIColor(red: 85.0/255.0, green: 238.0/255.0, blue: 151.0/255.0, alpha: 1)
    }

    
}
